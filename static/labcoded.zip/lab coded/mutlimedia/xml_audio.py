<RelativeLayout xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:app="http://schemas.android.com/apk/res-auto"
    xmlns:tools="http://schemas.android.com/tools"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    tools:context=".MainActivity">

    <!-- SeekBar for audio positioned at the top -->
    <SeekBar
        android:id="@+id/seekBar"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:layout_alignParentTop="true"
        android:max="100"
        android:layout_marginBottom="20dp" />

    <!-- Audio Controls: Play Button -->
    <Button
        android:id="@+id/btnPlay"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="Play"
        android:layout_below="@+id/seekBar"
        android:layout_centerHorizontal="true"
        android:layout_marginTop="10dp" />

    <!-- Audio Controls: Pause Button -->
    <Button
        android:id="@+id/btnPause"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="Pause"
        android:layout_below="@+id/btnPlay"
        android:layout_centerHorizontal="true"
        android:layout_marginTop="10dp" />

    <!-- Audio Controls: Stop Button -->
    <Button
        android:id="@+id/btnStop"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="Stop"
        android:layout_below="@+id/btnPause"
        android:layout_centerHorizontal="true"
        android:layout_marginTop="10dp" />
    <!-- Audio Controls: Stop Button -->
    <Button
        android:id="@+id/vid"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:layout_below="@+id/btnPause"
        android:layout_centerHorizontal="true"
        android:layout_marginTop="96dp"
        android:text="click me" />

    <!-- VideoView positioned below audio controls -->


</RelativeLayout>
