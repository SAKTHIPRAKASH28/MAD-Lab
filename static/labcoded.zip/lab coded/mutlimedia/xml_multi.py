<RelativeLayout xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:tools="http://schemas.android.com/tools"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:padding="16dp">

    <SurfaceView
        android:id="@+id/surfaceView"
        android:layout_width="match_parent"
        android:layout_height="300dp"
        android:layout_centerHorizontal="true"
        android:layout_marginTop="16dp" />

    <TextView
        android:id="@+id/mediaController"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="@string/media_controller_2"
        android:textSize="20sp"
        android:textStyle="bold"
        android:layout_above="@id/surfaceView"
        android:layout_centerHorizontal="true"
        android:layout_marginTop="16dp" />

    <VideoView
        android:id="@+id/videoView"
        android:layout_width="match_parent"
        android:layout_height="300dp"
        android:layout_below="@id/surfaceView"
        android:layout_centerHorizontal="true"
        android:layout_marginTop="16dp" />

    <LinearLayout
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:layout_below="@id/videoView"
        android:layout_centerHorizontal="true"
        android:orientation="horizontal">

        <Button
            android:id="@+id/button_record"
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:text="@string/record"
            android:layout_marginTop="16dp"
            android:layout_marginEnd="8dp"
            android:onClick="toggleRecording" />

        <Button
            android:id="@+id/button_playback"
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:text="@string/playback"
            android:visibility="gone"
            android:onClick="playbackVideo" />
    </LinearLayout>

    <Button
        android:id="@+id/button_exit"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="@string/exit"
        android:layout_below="@id/button_playback"
        android:layout_marginTop="16dp"
        android:layout_centerHorizontal="true"
        android:visibility="gone"
        android:onClick="exitApp"
        tools:ignore="NotSibling" />

</RelativeLayout>