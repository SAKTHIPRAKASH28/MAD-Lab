package com.example.lab;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.bluetooth.BluetoothAdapter;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.gesture.Gesture;
import android.net.Uri;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class MainActivity3 extends AppCompatActivity {

    private EditText recipientEditText;
    private EditText messageEditText;
    private Button sendButton;
    private Button scheduleButton;

    private EditText timeEditText;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        recipientEditText = findViewById(R.id.recipientEditText);
        messageEditText = findViewById(R.id.messageEditText);
        sendButton = findViewById(R.id.sendButton);

        scheduleButton = findViewById(R.id.scheduleButton);
        timeEditText = findViewById(R.id.timeEditText);

        sendButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String recipient = recipientEditText.getText().toString();
                String message = messageEditText.getText().toString();
                String[] recipients = recipient.split(","); // Split recipients by comma
                sendSMS(recipients, message);
            }
        });
        scheduleButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String recipient = recipientEditText.getText().toString();
                String message = messageEditText.getText().toString();
                String time = timeEditText.getText().toString(); // Get time from EditText
                long delayInMillis = Long.parseLong(time) * 1000;
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        sendSMS(recipient.split(","), message);
                    }
                }, delayInMillis); // 30 seconds delay
            }
        });




    }

    private void sendSMS(String[] recipients, String message) {
        for (String recipient : recipients) {
            Intent sendIntent = new Intent(Intent.ACTION_SENDTO);
            sendIntent.setData(Uri.parse("smsto:" + recipient.trim()));
            sendIntent.putExtra("sms_body", message);
            try {
                startActivity(Intent.createChooser(sendIntent, "Send SMS"));

            } catch (Exception e) {
                Toast.makeText(MainActivity3.this, "Failed to send SMS to " + recipient, Toast.LENGTH_SHORT).show();
                e.printStackTrace();
            }
        }
    }
    private String getTimeAfterDelay(int seconds) {
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.SECOND, seconds); // Add seconds to current time
        SimpleDateFormat sdf = new SimpleDateFormat("hh:mm a");
        return sdf.format(calendar.getTime());
    }

















}