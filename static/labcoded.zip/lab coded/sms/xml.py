<?xml version="1.0" encoding="utf-8"?>
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:tools="http://schemas.android.com/tools"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:orientation="vertical">
    <EditText
        android:id="@+id/recipientEditText"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:hint="Recipient" />

    <EditText
        android:id="@+id/messageEditText"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:hint="Message" />
    <EditText
        android:id="@+id/timeEditText"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:hint="Time" />
    <Button
        android:id="@+id/sendButton"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="Send" />
    <Button
        android:id="@+id/scheduleButton"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="Schedule" />

</LinearLayout>